package employee;

public class Employee {

}
