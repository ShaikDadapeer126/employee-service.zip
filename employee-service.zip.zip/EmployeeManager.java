package employee;

public class EmployeeManager {

}
