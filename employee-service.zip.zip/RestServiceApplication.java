package employee;

public class RestServiceApplication {

}
